# Introduction
BusinessApp is a free and elegant HTML5 and CSS3 based landing page template for showcasing your Android or iOS application on your website.

## What is working?

- Sliders
- jQuery Animations

## What is not working?

- Signup form. I am working on it. Otherwise you can use own script.

## What's need to be done?

- Making the layout responsive.
- A lot of tweaks and improvements.
- Compressing images.
- Minifying code.

## License
App-Landing-Page is licenced under GPL.
